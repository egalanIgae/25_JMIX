### Creating a New Jmix Guide

To create a new guide based on this example, follow these steps to set up and integrate your guide within the [Jmix Docs: CONTRIBUTING.md](https://github.com/jmix-framework/jmix-docs/blob/main/CONTRIBUTING.md
).

By following these guidelines, you’ll ensure your guide is ready for review and integration into the Jmix Docs.