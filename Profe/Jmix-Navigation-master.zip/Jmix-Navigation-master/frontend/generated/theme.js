import {applyTheme as _applyTheme} from './theme-Navigation.generated.js';
export const applyTheme = _applyTheme;
